const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const sqlite3 = require('sqlite3').verbose();
const app = express();

app.use(cors());
app.use(express.json());

const db = new sqlite3.Database('./db.sqlite');

// Create tables if not exist
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    title TEXT,
    description TEXT,
    created_at TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS slots (
    id TEXT PRIMARY KEY,
    event_id TEXT,
    start_time TEXT,
    max_bookings INTEGER,
    FOREIGN KEY(event_id) REFERENCES events(id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS bookings (
    id TEXT PRIMARY KEY,
    slot_id TEXT,
    event_id TEXT,
    name TEXT,
    email TEXT,
    booked_at TEXT,
    FOREIGN KEY(slot_id) REFERENCES slots(id),
    FOREIGN KEY(event_id) REFERENCES events(id)
  )`);
});

// Create new event with slots
app.post('/events', (req, res) => {
  const { title, description, slots, maxBookingsPerSlot } = req.body;
  if (!title || !slots || !Array.isArray(slots)) {
    return res.status(400).json({ error: 'Invalid data format' });
  }

  const eventId = uuidv4();
  const createdAt = new Date().toISOString();

  db.run(
    `INSERT INTO events (id, title, description, created_at) VALUES (?, ?, ?, ?)`,
    [eventId, title, description, createdAt],
    (err) => {
      if (err) return res.status(500).json({ error: err.message });

      const stmt = db.prepare(
        `INSERT INTO slots (id, event_id, start_time, max_bookings) VALUES (?, ?, ?, ?)`
      );

      slots.forEach((startTime) => {
        stmt.run(uuidv4(), eventId, startTime, maxBookingsPerSlot);
      });

      stmt.finalize();
      res.status(201).json({ eventId });
    }
  );
});

// Get all events
app.get('/events', (req, res) => {
  db.all(`SELECT * FROM events`, [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Get single event + slots
app.get('/events/:id', (req, res) => {
  const eventId = req.params.id;
  db.get(`SELECT * FROM events WHERE id = ?`, [eventId], (err, event) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!event) return res.status(404).json({ error: 'Event not found' });

    db.all(`SELECT * FROM slots WHERE event_id = ?`, [eventId], (err, slots) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ ...event, slots });
    });
  });
});

// Book a slot
app.post('/events/:id/bookings', (req, res) => {
  const eventId = req.params.id;
  const { slotId, name, email } = req.body;

  if (!slotId || !name || !email) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // Check if user already booked the same slot
  db.get(
    `SELECT * FROM bookings WHERE slot_id = ? AND email = ?`,
    [slotId, email],
    (err, existing) => {
      if (err) return res.status(500).json({ error: err.message });
      if (existing) return res.status(409).json({ error: 'You already booked this slot' });

      // Check if slot is full
      db.get(
        `SELECT COUNT(*) as count FROM bookings WHERE slot_id = ?`,
        [slotId],
        (err, countRes) => {
          if (err) return res.status(500).json({ error: err.message });

          db.get(
            `SELECT max_bookings FROM slots WHERE id = ?`,
            [slotId],
            (err, slot) => {
              if (err) return res.status(500).json({ error: err.message });
              if (!slot) return res.status(404).json({ error: 'Slot not found' });

              if (countRes.count >= slot.max_bookings) {
                return res.status(403).json({ error: 'Slot is full' });
              }

              // Book the slot
              const bookingId = uuidv4();
              const bookedAt = new Date().toISOString();

              db.run(
                `INSERT INTO bookings (id, slot_id, event_id, name, email, booked_at) VALUES (?, ?, ?, ?, ?, ?)`,
                [bookingId, slotId, eventId, name, email, bookedAt],
                (err) => {
                  if (err) return res.status(500).json({ error: err.message });
                  res.status(201).json({ bookingId });
                }
              );
            }
          );
        }
      );
    }
  );
});

// Get all bookings for a user (optional)
app.get('/users/:email/bookings', (req, res) => {
  const email = req.params.email;
  db.all(
    `SELECT bookings.*, slots.start_time, events.title FROM bookings
     JOIN slots ON bookings.slot_id = slots.id
     JOIN events ON bookings.event_id = events.id
     WHERE bookings.email = ?`,
    [email],
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
});
// GET /users/:email/bookings
app.get('/users/:email/bookings', (req, res) => {
  const email = req.params.email;
  db.all(
    `SELECT b.*, e.title AS event_title, s.start_time
     FROM bookings b
     JOIN events e ON b.event_id = e.id
     JOIN slots s ON b.slot_id = s.id
     WHERE b.email = ?`,
    [email],
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
});

const PORT = 5050;
app.listen(PORT, () => {
  console.log(`✅ Backend running at http://localhost:${PORT}`);
});

app.get('/events/:id', (req, res) => {
  const eventId = req.params.id;

  db.get(`SELECT * FROM events WHERE id = ?`, [eventId], (err, event) => {
    if (err || !event) return res.status(404).json({ error: 'Event not found' });

    db.all(
      `SELECT id, start_time FROM slots WHERE event_id = ? AND id NOT IN (
        SELECT slot_id FROM bookings
      )`,
      [eventId],
      (err, slots) => {
        if (err) return res.status(500).json({ error: err.message });
        event.slots = slots;
        res.json(event);
      }
    );
  });
});
db.run(`CREATE TABLE IF NOT EXISTS bookings (
  id TEXT PRIMARY KEY,
  event_id TEXT,
  slot_id TEXT,
  name TEXT,
  email TEXT,
  created_at TEXT,
  FOREIGN KEY(event_id) REFERENCES events(id),
  FOREIGN KEY(slot_id) REFERENCES slots(id)
)`);

app.post('/events/:id/bookings', (req, res) => {
  const { name, email, slotId } = req.body;
  const eventId = req.params.id;

  if (!name || !email || !slotId) {
    return res.status(400).json({ error: 'Missing data' });
  }

  db.get(
    `SELECT COUNT(*) AS count FROM bookings WHERE email = ? AND slot_id = ?`,
    [email, slotId],
    (err, row) => {
      if (err) return res.status(500).json({ error: err.message });
      if (row.count > 0) return res.status(409).json({ error: 'Already booked' });

      db.get(
        `SELECT COUNT(*) AS count FROM bookings WHERE slot_id = ?`,
        [slotId],
        (err, row2) => {
          if (err) return res.status(500).json({ error: err.message });

          db.get(
            `SELECT max_bookings FROM slots WHERE id = ?`,
            [slotId],
            (err, slot) => {
              if (err || !slot) return res.status(404).json({ error: 'Slot not found' });
              if (row2.count >= slot.max_bookings)
                return res.status(403).json({ error: 'Slot full' });

              db.run(
                `INSERT INTO bookings (id, event_id, slot_id, name, email, created_at)
                 VALUES (?, ?, ?, ?, ?, ?)`,
                [uuidv4(), eventId, slotId, name, email, new Date().toISOString()],
                (err) => {
                  if (err) return res.status(500).json({ error: err.message });
                  res.status(201).json({ success: true });
                }
              );
            }
          );
        }
      );
    }
  );
});
