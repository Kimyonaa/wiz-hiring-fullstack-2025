import { useLocation } from 'react-router-dom';

export default function Layout({ children }) {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-gray-950 text-white px-6 py-8">
      {children}
      {location.pathname === '/' && (
        <footer className="mt-10 text-center text-gray-500 text-sm">
          Made with ❤️ by Anupam Nainiwal
        </footer>
      )}
    </div>
  );
}
