import { Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import CreateEvent from './pages/CreateEvent';
import EventDetails from './pages/EventDetails';

export default function App() {
  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#111827', color: 'white', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '2rem', textAlign: 'center' }}>
      <nav style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1rem' }}>📅 BookMySlot</h1>
        <div>
          <Link to="/" style={{ color: '#f9fafb', marginRight: '1rem', textDecoration: 'none', fontSize: '1.1rem' }}>Home</Link>
          <Link to="/create" style={{ color: '#f9fafb', textDecoration: 'none', backgroundColor: '#2563eb', padding: '0.5rem 1rem', borderRadius: '0.375rem', fontSize: '1.1rem', border: 'none' }}>+ Create Event</Link>
        </div>
      </nav>

      <div style={{ width: '100%', maxWidth: '800px' }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/create" element={<CreateEvent />} />
          <Route path="/events/:id" element={<EventDetails />} />
        </Routes>
      </div>
    </div>
  );
}