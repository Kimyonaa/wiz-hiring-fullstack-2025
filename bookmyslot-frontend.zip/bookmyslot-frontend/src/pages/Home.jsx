import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

export default function Home() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('http://localhost:5050/events')
      .then((res) => res.json())
      .then(setEvents)
      .catch(() => setError('Failed to fetch events'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#0f172a', color: 'white', padding: '2rem' }}>
      {loading ? (
        <p style={{ color: '#94a3b8' }}>⏳ Loading events...</p>
      ) : error ? (
        <p style={{ color: 'red' }}>{error}</p>
      ) : events.length === 0 ? (
        <p style={{ color: '#94a3b8' }}>No events created yet. Be the first!</p>
      ) : (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1.5rem', justifyContent: 'center' }}>
          {events.map((event) => (
            <Link
              to={`/events/${event.id}`}
              key={event.id}
              style={{
                backgroundColor: '#1f2937',
                padding: '1.25rem',
                borderRadius: '0.5rem',
                width: '300px',
                textDecoration: 'none',
                color: 'white',
                boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
                transition: 'background 0.3s'
              }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#374151')}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#1f2937')}
            >
              <h2 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '0.5rem' }}>{event.title}</h2>
              <p style={{ color: '#cbd5e1', fontSize: '0.875rem' }}>{event.description}</p>
              <p style={{ color: '#94a3b8', fontSize: '0.75rem', marginTop: '0.5rem' }}>
                Created on {new Date(event.created_at).toLocaleDateString()}
              </p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}