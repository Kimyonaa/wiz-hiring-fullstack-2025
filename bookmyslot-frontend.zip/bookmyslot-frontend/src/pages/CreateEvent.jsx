import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function CreateEvent() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [slots, setSlots] = useState(['']);
  const [maxBookings, setMaxBookings] = useState(1);
  const [showUserDetails, setShowUserDetails] = useState(false);
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');

  const navigate = useNavigate();

  const handleSlotChange = (index, value) => {
    const newSlots = [...slots];
    newSlots[index] = value;
    setSlots(newSlots);
  };

  const addSlotField = () => setSlots([...slots, '']);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch('http://localhost:5050/events', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        description,
        slots,
        maxBookingsPerSlot: parseInt(maxBookings)
      })
    });

    if (res.ok) {
      const { eventId } = await res.json();
      navigate(`/events/${eventId}`);
    } else {
      alert('Failed to create event');
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        color: '#e2e8f0',
        background: '#0f172a',
        padding: '2rem',
        borderRadius: '10px',
        maxWidth: '600px',
        margin: '2rem auto'
      }}
    >
      <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Create Event</h2>

      <label style={{ display: 'block', marginBottom: '0.5rem' }}>Title:</label>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
        style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', background: '#1e293b', color: 'white', border: 'none', borderRadius: '5px' }}
      />

      <label style={{ display: 'block', marginBottom: '0.5rem' }}>Description:</label>
      <input
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', background: '#1e293b', color: 'white', border: 'none', borderRadius: '5px' }}
      />

      <label style={{ display: 'block', marginBottom: '0.5rem' }}>Time Slots:</label>
      {slots.map((slot, idx) => (
        <input
          key={idx}
          type="datetime-local"
          value={slot}
          onChange={(e) => handleSlotChange(idx, e.target.value)}
          required
          style={{ width: '100%', padding: '0.5rem', marginBottom: '0.5rem', background: '#1e293b', color: 'white', border: 'none', borderRadius: '5px' }}
          onFocus={() => setShowUserDetails(true)}
        />
      ))}
      <button
        type="button"
        onClick={addSlotField}
        style={{ marginBottom: '1rem', background: '#1f2937', color: 'white', padding: '0.5rem', borderRadius: '5px', border: 'none' }}
      >
        + Add Another Slot
      </button>

      {showUserDetails && (
        <div style={{ marginBottom: '1.5rem' }}>
          <label style={{ display: 'block', marginBottom: '0.5rem' }}>Your Name:</label>
          <input
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            style={{ width: '100%', padding: '0.5rem', marginBottom: '1rem', background: '#1e293b', color: 'white', border: 'none', borderRadius: '5px' }}
          />
          <label style={{ display: 'block', marginBottom: '0.5rem' }}>Your Email:</label>
          <input
            type="email"
            value={userEmail}
            onChange={(e) => setUserEmail(e.target.value)}
            style={{ width: '100%', padding: '0.5rem', background: '#1e293b', color: 'white', border: 'none', borderRadius: '5px' }}
          />
        </div>
      )}

      <label style={{ display: 'block', marginBottom: '0.5rem' }}>Max bookings per slot:</label>
      <input
        type="number"
        value={maxBookings}
        onChange={(e) => setMaxBookings(e.target.value)}
        min={1}
        style={{ width: '100%', padding: '0.5rem', marginBottom: '1.5rem', background: '#1e293b', color: 'white', border: 'none', borderRadius: '5px' }}
      />

      <button
        type="submit"
        style={{ background: '#2563eb', color: 'white', padding: '0.75rem 1.5rem', borderRadius: '5px', border: 'none', cursor: 'pointer' }}
      >
        Create
      </button>
    </form>
  );
}
