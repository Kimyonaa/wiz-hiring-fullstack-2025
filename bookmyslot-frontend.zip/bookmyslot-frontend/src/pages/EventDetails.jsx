import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';

export default function EventDetails() {
  const { id } = useParams();
  const [event, setEvent] = useState(null);
  const [slots, setSlots] = useState([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [selectedSlot, setSelectedSlot] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetch(`http://localhost:5050/events/${id}`)
      .then(res => res.json())
      .then(data => {
        setEvent(data.event);
        setSlots(data.slots);
      })
      .catch(() => setMessage('Failed to load event'));
  }, [id]);

  const handleBooking = async (e) => {
    e.preventDefault();

    const res = await fetch(`http://localhost:5050/events/${id}/bookings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, slotId: selectedSlot }),
    });

    const data = await res.json();
    if (res.ok) {
      setMessage('✅ Booking successful!');
    } else {
      setMessage('❌ ' + (data?.error || 'Booking failed'));
    }
  };

  if (!event) return <p style={{ color: 'white' }}>Loading...</p>;

  return (
    <div style={{ backgroundColor: '#111827', color: 'white', padding: '2rem', maxWidth: '600px', margin: '0 auto', borderRadius: '8px' }}>
      <h2 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>{event.title}</h2>
      <p style={{ marginBottom: '1rem' }}>{event.description}</p>

      <h3 style={{ fontSize: '1.25rem', marginBottom: '0.5rem' }}>Available Time Slots</h3>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {slots.map(slot => (
          <li key={slot.id} style={{ marginBottom: '0.5rem' }}>
            <label>
              <input
                type="radio"
                name="slot"
                value={slot.id}
                onChange={e => setSelectedSlot(e.target.value)}
                style={{ marginRight: '0.5rem' }}
              />
              {new Date(slot.start_time).toLocaleString()}
            </label>
          </li>
        ))}
      </ul>

      <form onSubmit={handleBooking} style={{ marginTop: '1rem' }}>
        <h4 style={{ marginBottom: '0.5rem' }}>Book this slot</h4>
        <input
          type="text"
          placeholder="Your Name"
          value={name}
          onChange={e => setName(e.target.value)}
          required
          style={{ width: '100%', padding: '0.5rem', marginBottom: '0.5rem', borderRadius: '4px', border: 'none' }}
        />
        <input
          type="email"
          placeholder="Your Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          required
          style={{ width: '100%', padding: '0.5rem', marginBottom: '0.5rem', borderRadius: '4px', border: 'none' }}
        />
        <button type="submit" disabled={!selectedSlot} style={{ padding: '0.5rem 1rem', backgroundColor: '#2563eb', color: 'white', border: 'none', borderRadius: '4px' }}>
          Book Slot
        </button>
      </form>

      {message && <p style={{ marginTop: '1rem', color: '#facc15' }}>{message}</p>}
    </div>
  );
}